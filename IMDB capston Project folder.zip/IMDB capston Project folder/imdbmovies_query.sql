use project_movie_database;
show databases;
show tables;
select * from movies;
select * from directors;
select count(*) from movies;

 select * from movies m
 inner join directors d
 on m.director_id =d.id;
 
 select * from directors
 where name in("janmes cameraon","luc besson","john woo");
 select * from directors
 where name like 's%';
 select count(*) from directors
 where 	gender = 1;
 
 select * from directors
 where gender = 1 
  order by gender 
  limit 9,1;
  
  select * from movies
  order by popularity desc
  limit 3;
  
select * from movies
order by revenue desc
limit 3;

select * from movies
where release_date >='2000-01-01'
order by vote_average desc
limit 1 ;

select m.* from movies m
join directors d
on m.director_id = d.id
where d.name = 'Brenda Chappman';

  select director_id,count(*) as total_movies
  from movies
  group by director_id 
  order by total_movies desc
  limit 1;
  
  select
      d.name , sum(m.revenue) as total_revenue
  from movies m
   join directors d on m.director_id =d.id group by d.id,d.name
  order by total_revenue desc
  limit 1;
  
  select * from movies
  where id is null;
	
    SELECT
    SUM(id IS NULL) AS null_ids,
    SUM(original_title IS NULL) AS null_original_titles,
    SUM(budget IS NULL) AS null_budgets,
    SUM(popularity IS NULL) AS null_popularity,
    SUM(release_date IS NULL) AS null_release_dates,
    SUM(revenue IS NULL) AS null_revenue,
    SUM(title IS NULL) AS null_titles,
    SUM(vote_average IS NULL) AS null_vote_averages,
    SUM(vote_count IS NULL) AS null_vote_counts
FROM movies;
